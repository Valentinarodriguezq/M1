# Homework Algoritmos II

## QuickSort

* Implementa el algoritmo según lo explicado en la Lecture

## MergeSort

* Implementa el algoritmo según lo explicado en la Lecture

## Extra Credit

### HeapSort

* Implementa el algoritmo en:
  * Un árbol binario
  * En un arreglo (recuerden como guardar árboles binarios en un arreglo)

### BFS y DFS

* Implementar un algoritmo para recorrer un árbol de las dos formas.
* Usar el algoritmo implementado para poder buscar un elemento dentro del árbol.
