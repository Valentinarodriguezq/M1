# Homework Estructuras de Datos II

Escribir las soluciones a los ejercicios en `homework.js`.

Para correr los tests, desde la carpeta `homework` ejecutar:

```bash
npm install
```

```bash
npm test DataStructureII.test.js
```
