# Homework Estructuras de Datos I

Escribir las soluciones a los ejercicios en `homework.js`.

Para correr los tests, desde la carpeta `homework` ejecutar:

```bash
npm install
```

```bash
npm test DataStructure.test.js
```